# naive-bayes-classifier-python
Implementasi metode klasifikasi algoritma naive bayes dengan jupiter notebook (anaconda3) dengan data sample hasil survei SNMPTN UI 2017 oleh halo kampus yang sudah dilakukan cleaning data

require :
  1. Anaconda 3
# Data Latih  
![data](https://user-images.githubusercontent.com/33270746/70891046-05b15380-2019-11ea-8fac-1a15b49259bd.png)

# Data Uji
![datauji](https://user-images.githubusercontent.com/33270746/70891213-66409080-2019-11ea-94b6-b26c38522340.png)

# Hasil Prediksi
![predict](https://user-images.githubusercontent.com/33270746/70891048-0649ea00-2019-11ea-894d-a7f4038dfcbb.png)

